import sys,math
import pygame
import keyboard as k
falling=False
pygame.init()
pygame.display.set_caption('Mr. Longlegs')
pygame.display.set_icon(pygame.image.load('icon.png'))
screen = pygame.display.set_mode((1600, 1000))
clock = pygame.time.Clock()
pic1=True
pic2=False
dt = 0
vektorx=0
vektory=0
counting=0
isgrounded=False
knocked=False
knockedcounter=0
player_pos = pygame.Vector2(1400,800)
idle0=pygame.image.load("idle0.png")
idle1=pygame.image.load("idle1.png")
movingpng=pygame.image.load("moving.png")
movinglowpng=pygame.image.load("movinglow.png")
box0=pygame.image.load("box0.png")
tutorial=pygame.image.load("tutorial.png")
knockedpic=pygame.image.load("knocked.png")

boxlistx=[1500,1400,1100,1000, 950, 200, 450, 700, 950,1050,1150,1250,1350,1300]
boxlisty=[ 900, 900, 800, 700, 600, 800, 700, 600, 500, 500, 500, 500,   500, 300]
def drawbox(x,y):
    global vektorx
    global vektory
    global isgrounded
    global player_pos
    global knocked
    if player_pos.x>(x+50) and player_pos.x<=(x+100) and player_pos.y>(y-90) and player_pos.y<(y+90) and vektorx<0:
        knocked=True
        player_pos.x=x+100
    if player_pos.x>=(x-100) and player_pos.x<(x-50) and player_pos.y>(y-90) and player_pos.y<(y+90) and vektorx>0:
        knocked=True
        player_pos.x=x-100
    if player_pos.x>(x-100) and player_pos.x<(x+100) and player_pos.y>=(y-100) and player_pos.y<(y-50) and vektory>=0:
        vektory=0
        player_pos.y=y-100
        isgrounded=True
    if player_pos.x>(x-100) and player_pos.x<(x+100) and player_pos.y>(y+50) and player_pos.y<=(y+100) and vektory<0:
        vektory=-0.3*vektory
        player_pos.y=y+100
    screen.blit(box0, (x,y))

def vektorxrunden():
    global vektorx
    if vektorx>-2 and vektorx<2:
        vektorx=0

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        #zeichen 
    screen.fill("purple")
    screen.blit(tutorial, (100,100))
    
        #playercontrol
    if knocked==False:
        if k.is_pressed("w") or k.is_pressed("space"): 
            if isgrounded:
                vektory = -16.5 
        if k.is_pressed("a") and isgrounded and k.is_pressed("s")==False:
            vektorx -= 3 
        if k.is_pressed("d") and isgrounded and k.is_pressed("s")==False:
            vektorx += 3 
    
        #knocked
    if knocked and knockedcounter==0:
        if math.sqrt(vektorx*vektorx+vektory*vektory)<25.5:
            knocked=False
        vektory=-16.5
        vektorx=-0.4*vektorx
    if knocked and knockedcounter<120:
        knockedcounter+=1
    if knocked and knockedcounter==120:
        knockedcounter=0
        knocked=False
    
        #fall checks    
    falling=True 
    if isgrounded:
        falling=False
    if falling: 
        vektory+=1
    
        #border links und rechts
    if player_pos.x>=1500 and vektorx>0: 
        knocked=True
        player_pos.x=1500
    if player_pos.x<=0 and vektorx<0:
        knocked=True
        player_pos.x=0
    vektorxrunden()
    
        #Reibungskräfte
    vektorx=vektorx*0.98 
    if isgrounded and k.is_pressed("s")==False:
        vektorx=vektorx*0.92
    if isgrounded and k.is_pressed("shift"):
        vektorx=vektorx*0.9
    vektorxrunden()

        #bewegung
    player_pos.x=player_pos.x+vektorx 
    player_pos.y=player_pos.y+vektory  

        #isgrounded checks
    isgrounded=False 
    for i in range(len(boxlistx)):
        drawbox(boxlistx[i],boxlisty[i])
    if player_pos.y>=900:
        isgrounded=True
        player_pos.y=900
    
        #moving checks
    moving=True 
    vektorxrunden()
    if vektorx==0 and isgrounded:
        moving=False

        #Auswahl des Player Bildes
    if moving: 
        playerpicture=movingpng       
    else:
        pic2=True
        if pic1:
            playerpicture=idle0
            counting+=1
            pic2=False
            if counting>40:
                pic1=False
                counting=0
        if pic2:
            playerpicture=idle1
            counting+=1
            if counting>40:
                pic1=True
                counting=0
    if k.is_pressed("s"):
        playerpicture=movinglowpng
    if knocked:
        playerpicture=knockedpic
    
        #zeichnen des Spielers
    screen.blit(playerpicture, (player_pos.x, player_pos.y))
    
        #pygamestandarts
    pygame.display.flip()
    dt = clock.tick(60) / 1000


