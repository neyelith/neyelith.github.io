import pygame
import drawbox_boxfight as dbf

block_none = pygame.image.load('block_none.png')
block_core_blue = pygame.image.load('block_core_blue.png')
block_core_red = pygame.image.load('block_core_red.png')
unit_knight = pygame.image.load('unit_knight.png')
unit_simple_spikes = pygame.image.load('block_simple_spikes.png')
unit_imperialknight = pygame.image.load('unit_imperialknight.png')

def getunitinfo(unit='', xy=[],y=0, xlevelofplayfield = 0, ylevelofplayfield = 100, enemy = -1):
    if unit == 'knight':
        return [unit_knight, xy[0] * 50 + xlevelofplayfield, xy[1] * 50 + ylevelofplayfield, 5, 1, 2, .2, 2, 0, -20, -enemy, 0, .5, 0]
    if unit == 'spikes':
        return [unit_simple_spikes, xy[0] * 50 + xlevelofplayfield, xy[1] * 50 + ylevelofplayfield, 2, 0, 2, 0, 2, 0, -20, -enemy, 0, 0, 0]
    if unit == 'imperialknight':
        return [unit_imperialknight, xy[0] * 50 + xlevelofplayfield, xy[1] * 50 + ylevelofplayfield, 5, 1, 2, .2, 2, 0, -20, -enemy, 0, .5, 0]
    if unit == 'b_core':
        return [block_core_blue, xy[0] * 50 + xlevelofplayfield, xy[1] * 50 + ylevelofplayfield, 50, 0, 0, 0, .2, 0, -20, -enemy, 0, 1, 1]
    if unit == 'r_core':
        return [block_core_red, xy[0] * 50 + xlevelofplayfield, xy[1] * 50 + ylevelofplayfield, 50, 0, 0, 0, .2, 0, -20, -enemy, 0, 1, 1]

def checkforplacability(notplacableoverlist=[] ,x=0, y=100, boardheight = 15):
    mouse = pygame.Vector2(pygame.mouse.get_pos())
    if mouse.x - x > 0 and mouse.x - x < 300 and mouse.y - y > 0 and mouse.y - y < boardheight * 50:
        mousey = dbf.find_currentmouseposition(x)
        if notplacableoverlist[int(mousey[1])][int(mousey[0])] == None:
            return True
    return False
    