import pygame, pygame_widgets, sys, os


x = 50
y = 50
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)
screenwidth = 1800
screenheight = 900
pygame.init()
pygame.display.set_caption('cardgame')
pygame.display.set_icon(pygame.image.load('icon.png'))
screen = pygame.display.set_mode((screenwidth, screenheight))
clock = pygame.time.Clock()

def standardstart():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill("grey")

def standardend():
    pygame_widgets.update(pygame.event.get())
    pygame.display.update()
    pygame.display.flip()

number1 = pygame.image.load('Number1.png')
number2 = pygame.image.load('Number2.png')
number3 = pygame.image.load('Number3.png')
number4 = pygame.image.load('Number4.png')
number5 = pygame.image.load('Number5.png')
number6 = pygame.image.load('Number6.png')
number7 = pygame.image.load('Number7.png')
number8 = pygame.image.load('Number8.png')
number9 = pygame.image.load('Number9.png')
number0 = pygame.image.load('Number0.png')
listofnumbers = [number0, number1, number2, number3, number4, number5, number6, number7, number8, number9]

def shownumber(number = 0, x = 100, y = 100, centered = True):
    listx = [int(xi) for xi in str(abs(number))]
    if centered == True:
        subtraction = len(listx) * 15
    else:
        subtraction = 0
    for i  in range(len(listx)):
        screen.blit(listofnumbers[listx[i]], (x + 30 * i - subtraction, y))

def pywrite(text = '', x = 0, y = 0, size = 20, font = "monospace", color = (0, 0, 0)):
    screen.blit(pygame.font.SysFont(font, size).render(text, 1, color), (x, y))
