import pygame, math

block_none = pygame.image.load('block_none.png')
block_marker = pygame.image.load('block_marker.png')
block_air = pygame.image.load('block_air.png')
block_dirt = (pygame.image.load('block_dirt.png'), 20, 0)


block_simple_spikes = pygame.image.load('block_simple_spikes.png')

def create_playfield(boardwidth = 20, boardheight = 15):
  
    mapcoloumlist = []
    for i in range (boardheight):
        mapcoloum = []
        for k in range (boardwidth):
            mapcoloum.append(block_air)
        mapcoloumlist.append(mapcoloum)
    

    return mapcoloumlist

def create_activeplayfield(boardwidth = 20, boardheight = 15):
    mapcoloumlist = []
    for i in range (boardheight):
        mapcoloum = []
        for k in range (boardwidth):
            mapcoloum.append(None)
        mapcoloumlist.append(mapcoloum)

    for i in range (3):
        for k in range (boardwidth):
            mapcoloumlist[i+boardheight-3][k] = block_dirt
            

    return mapcoloumlist

def find_currentmouseposition(x = 0, y = 100):     
    mousepos = pygame.Vector2(pygame.mouse.get_pos())
    if mousepos.x - x < 0:
        mousepos.x -= 50
    if mousepos.y - y < 0:
        mousepos.y -= 50
    mousepos.x = int((mousepos.x - x) /50) #find integer for x and y used in the grid
    mousepos.y = int((mousepos.y - y) /50)
    return [mousepos.x, mousepos.y]

def marker(inbox):
    if inbox:
        return block_marker
    else:
        return block_none

def boxchecker(x=0, y=0, boardwidth = 0, boardheight = 0):
    if x >= 0 and y >= 0 and x < boardwidth and y < boardheight:
        return True
    else:
        return False

def groundcheck(x=0, y=0, blockswithhitbox=[], xlevel=0, ylevel=100):
    try:
        if blockswithhitbox[int((y-ylevel)/50)+1][int((x-xlevel)/50)] == None:
            return False
        else:
            return True
    except:
        return True

def closestunitcheck(freeunitlist=[], enemyunitlist=[], minimumdistance=40):
    currentdistance = 9999
    mouse = pygame.Vector2(pygame.mouse.get_pos())
    for i in freeunitlist:
        mydistance = math.sqrt((i[1]+25 - mouse.x)**2 + (i[2]+25 - mouse.y)**2)
        if mydistance < currentdistance:
            currentdistance = mydistance
            closestunit = i
    for i in enemyunitlist:
        mydistance = math.sqrt((i[1]+25 - mouse.x)**2 + (i[2]+25 - mouse.y)**2)
        if mydistance < currentdistance:
            currentdistance = mydistance
            closestunit = i
        if currentdistance > minimumdistance:
            closestunit = None
    return closestunit

def rightofmecheck(x=0, y=0, blocks=[], enemy=[], attackrange=.5, xlevel = 0, ylevel = 100):
    for i in enemy:
        if (x - i[1]) < 25 and (x - i[1]) > -50 - attackrange * 50  and (y - i[2]) > -25 and (y - i[2]) < 25:
            return 0
    #for i in blocks:
    #    if :
    #        return 0
    return 1

def leftofmecheck(x=0, y=0, blocks=[], enemy=[], attackrange=.5, xlevel = 0, ylevel = 100):
    for i in enemy:
        if (x - i[1]) > -25 and (x - i[1]) < +50 + attackrange * 50  and (y - i[2]) > -25 and (y - i[2]) < 25:
            return 0
    #for i in blocks:
    #    if :
    #        return 0
    return 1

def rightattack(x=0, y=0, blocks=[], enemy=[], attackrange=.5, xlevel = 0, ylevel = 100, damage=0, windup = 0, fps=60):
    currentdistance = 9999
    currentenemy = None
    for i in enemy:
        if (x - i[1]) < 25 and (x - i[1]) > -50 - attackrange * 50  and (y - i[2]) > -25 and (y - i[2]) < 25:
            if currentdistance > math.sqrt((x - i[1])**2 + (y - i[2])**2):
                currentdistance = math.sqrt((x - i[1])**2 + (y - i[2])**2)
                currentenemy = i
    if windup >= 100:
        currentenemy[3] -= (damage - currentenemy[4])#dmg calculation
        windup = 0
    else:
        windup += 25/fps
    return [windup, enemy]

def leftattack(x=0, y=0, blocks=[], enemy=[], attackrange=.5, xlevel = 0, ylevel = 100, damage=0, windup = 0, fps=60):
    currentdistance = 9999
    currentenemy = None
    for i in enemy:
        if (x - i[1]) > -25 and (x - i[1]) < +50 + attackrange * 50  and (y - i[2]) > -25 and (y - i[2]) < 25:
            if currentdistance > math.sqrt((x - i[1])**2 + (y - i[2])**2):
                currentdistance = math.sqrt((x - i[1])**2 + (y - i[2])**2)
                currentenemy = i
    if windup >= 100:
        currentenemy[3] -= (damage - currentenemy[4])#dmg calculation
        windup = 0
    else:
        windup += 25/fps
    return [windup, enemy]