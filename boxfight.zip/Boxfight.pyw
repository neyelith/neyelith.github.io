import pygame, pygameessentials as pes
import drawbox_boxfight as dbf
import units_boxfight as ubf


pygame.init()##
pygame.display.set_caption('boxfight')
pygame.display.set_icon(pygame.image.load('icon.png'))

def agametoplay(  screenwidth = 1800, ##
                            screenheight = 1080,
                            fps = 60,
                            boardheight = 12,
                            boardwidth = 15,
                            xlevelofplayfield = 1800/2 - 15*25,
                            ylevelofplayfield = 100,
                            maxpower = 100,
                            currentpower = 0,
                            canplace = True,
                            closestunit = None,
                            freeunitlist = [],#list of all free moving units on screen
                            enemyunitlist = [],
                            standartgamespeed = 4):
                            
    mapcoloumlist = dbf.create_playfield(boardwidth, boardheight)
    unitcoloumlist =dbf.create_activeplayfield(boardwidth, boardheight)

    
    screen = pygame.display.set_mode((screenwidth, screenheight))
    clock = pygame.time.Clock() ##
    gamespeed = standartgamespeed
    gamecycle = 0

    freeunitlist.append(ubf.getunitinfo('b_core', [1, 0], 0, xlevelofplayfield, ylevelofplayfield))
    enemyunitlist.append(ubf.getunitinfo('r_core', [boardwidth - 2, 0], 0, xlevelofplayfield, ylevelofplayfield, enemy=1))
    enemyunitlist.append(ubf.getunitinfo('imperialknight', [100, 50], 0, xlevelofplayfield, ylevelofplayfield, enemy=1))


    youwin = 1
    youloose = 1
    while youwin == 1 and youloose == 1:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                youloose = 2
                pygame.quit()
                sys.exit()
        screen.fill("grey")
        inbox = dbf.boxchecker(dbf.find_currentmouseposition(x=xlevelofplayfield)[0], dbf.find_currentmouseposition(x=xlevelofplayfield)[1], boardwidth, boardheight)#check if in playfield, returns True/False
        clock.tick(fps)

        gamecycle += 60*gamespeed/fps
        while gamecycle >= 1:
            gamecycle -= 1
            #gamelogic
    
            if currentpower < maxpower:
                currentpower += 1/60
        


            if pygame.mouse.get_pressed(3)[0]:#place unit
                if currentpower >= 10 and canplace and ubf.checkforplacability(unitcoloumlist, xlevelofplayfield):
                    canplace = False
                    currentpower -= 10
                    freeunitlist.append(ubf.getunitinfo('knight', dbf.find_currentmouseposition(xlevelofplayfield), 0, xlevelofplayfield, 100))
            else: 
                canplace = True

            if pygame.mouse.get_pressed(3)[2]:#inspect unit
                closestunit = dbf.closestunitcheck(freeunitlist, enemyunitlist)

            for i in freeunitlist:
                grounded = dbf.groundcheck(i[1], i[2], unitcoloumlist, xlevelofplayfield, ylevelofplayfield)
                if grounded:
                   i[9] = int(-abs(i[9]*0.6))#vy wird ge�ndert
                   i[2] = int(i[2]/50)*50#vy gerundet
           
                   i[8] += i[6] * i[10]#x accelerate
                else:
                    i[9] += i[7]#y accelerate

                i[8] = i[8] * dbf.rightofmecheck(i[1], i[2], enemy=enemyunitlist, xlevel=xlevelofplayfield)
                if dbf.rightofmecheck(i[1], i[2], enemy=enemyunitlist, xlevel=xlevelofplayfield) == 0:
                    outcome = dbf.rightattack(i[1], i[2], enemy=enemyunitlist, xlevel=xlevelofplayfield, damage=i[5], windup=i[11], fps=fps)
                    i[11] = outcome[0]
                    enemyunitlist = outcome[1]

                i[8] = 0.6 * i[8]#x friction
                i[1] += i[8]#x 
                i[9] = 0.95 * i[9]#y friction
                i[2] += i[9]#y

                if i[1] > xlevelofplayfield + boardwidth * 50 - 50: 
                    i[1] = xlevelofplayfield + boardwidth * 50 - 50 #border
                if i[1] < xlevelofplayfield:
                    i[1] = xlevelofplayfield
                if i[2] > ylevelofplayfield  + boardheight * 50 -50 or i[2] < ylevelofplayfield:
                    i[2] = ylevelofplayfield
        
            for i in enemyunitlist:
                grounded = dbf.groundcheck(i[1], i[2], unitcoloumlist, xlevelofplayfield, ylevelofplayfield)
                if grounded:
                   i[9] = int(-abs(i[9]*0.6))#vy wird ge�ndert
                   i[2] = int(i[2]/50)*50#vy gerundet
           
                   i[8] += i[6] * i[10]#x accelerate
                else:
                    i[9] += i[7]#y accelerate

                i[8] = i[8] * dbf.leftofmecheck(i[1], i[2], enemy=freeunitlist, xlevel=xlevelofplayfield)
                if dbf.leftofmecheck(i[1], i[2], enemy=freeunitlist, xlevel=xlevelofplayfield) == 0:
                    outcome = dbf.leftattack(i[1], i[2], enemy=freeunitlist, xlevel=xlevelofplayfield, damage=i[5], windup=i[11], fps=fps)
                    i[11] = outcome[0]
                    freeunitlist = outcome[1]

                i[8] = 0.6 * i[8]#x friction
                i[1] += i[8]#x 
                i[9] = 0.95 * i[9]#y friction
                i[2] += i[9]#y
        
                if i[1] > xlevelofplayfield + boardwidth * 50 - 50: 
                    i[1] = xlevelofplayfield + boardwidth * 50 - 50 #border
                if i[1] < xlevelofplayfield:
                    i[1] = xlevelofplayfield
                if i[2] > ylevelofplayfield  + boardheight * 50 -50 or i[2] < ylevelofplayfield:
                    i[2] = ylevelofplayfield
    
            for i in freeunitlist:
                if i[3] <= 0:
                    youloose = youloose * (i[13]+1)
                    freeunitlist.remove(i)#death
            for i in enemyunitlist:
                if i[3] <= 0:
                    youwin = youwin * (i[13]+1)
                    enemyunitlist.remove(i)#death

        #drawing the game
        for i in range (boardheight):#draws bg blocks
            for k in range (boardwidth):
                screen.blit(mapcoloumlist[i][k], (k * 50 + xlevelofplayfield, i * 50 + ylevelofplayfield))

        for i in range (boardheight):#draws unit blocks (dirt)
            for k in range (boardwidth):
                if not unitcoloumlist[i][k] ==None:
                    screen.blit(unitcoloumlist[i][k][0], (k * 50 + xlevelofplayfield, i * 50 + ylevelofplayfield))

        for i in freeunitlist:
            screen.blit(i[0], (i[1],i[2]))
        for i in enemyunitlist:
            screen.blit(i[0], (i[1],i[2]))
    
        if not closestunit == None:
            i = closestunit
            screen.blit(i[0], (500, 900))
            screen.blit(dbf.marker(True), (i[1], i[2]))
            pes.shownumber(i[3], 600, 800, False)
            pes.shownumber(i[4], 600, 850, False)
            pes.shownumber(i[5], 600, 900, False)

        pes.shownumber(int(currentpower), 100, 100, False)
            
        screen.blit(dbf.marker(inbox), (dbf.find_currentmouseposition(x=xlevelofplayfield)[0] * 50 + xlevelofplayfield, dbf.find_currentmouseposition(x=xlevelofplayfield)[1] * 50 + ylevelofplayfield)) #draw the marker if in the playboard
    
        #mouse = pygame.Vector2(pygame.mouse.get_pos())
        #for i in enemyunitlist:
        #    i[1] = mouse.x
        #    i[2] = mouse.y

        pes.standardend()
    return youwin - youloose

def main():
    win = agametoplay()
    while True:
        pes.standardstart()
        if win == 1:
            pes.pywrite('you won')
        else:
            pes.pywrite('you lost')
        pes.standardend()

main()
