import pygameessentials as pes, pygame as pg, os,time

def gameoftictactoe():

    time.sleep(0.5)
    x = 300
    y = 100
    os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)
    screenwidth = 700
    screenheight = 700
    pg.init()
    screen = pg.display.set_mode((screenwidth, screenheight))
    clock = pg.time.Clock()
    hover = pg.image.load('hover.png')
    grid = pg.image.load('grid.png')
    gamefield = []

    for i in range (3):
        gamefield.append([None, None, None])

    turn = 'X'
    turnnumber = 1
    while True:
        pes.standardstart()
        screen.blit(grid, (0, 0))
        
        mouse = pg.Vector2(pg.mouse.get_pos())
        mousepress = pg.mouse.get_pressed()[0]

        hoveredspace = [int((mouse.x - 100) / 167), int((mouse.y - 100) / 167)]
    
        if hoveredspace[0] >= 0 and hoveredspace[0] <= 2 and hoveredspace[1] >= 0 and hoveredspace[1] <= 2:

            screen.blit(hover, (hoveredspace[0]*167 + 100, hoveredspace[1]*167 + 100))

            if mousepress and gamefield[hoveredspace[1]][hoveredspace[0]] == None:
                gamefield[hoveredspace[1]][hoveredspace[0]] = turn

                # ---
                for i in range (3):
                    if not gamefield[i][0] == None:
                        leftfield = gamefield[i][0] 
                        if gamefield[i][1] == leftfield and gamefield[i][2] == leftfield:
                            return leftfield
                # l
                for i in range (3):
                    if not gamefield[0][i] == None:
                        topfield = gamefield[0][i]
                        if gamefield[1][i] == topfield and gamefield[2][i] == topfield:
                            return topfield
                # \
                middlefield = gamefield[1][1]
                if not middlefield == None:
                    if gamefield[0][0] == middlefield and gamefield[2][2] == middlefield:
                        return middlefield
                    if gamefield[2][0] == middlefield and gamefield[0][2] == middlefield:
                        return middlefield

                if turn == 'X':
                    turn = 'O'
                else:
                    turn = 'X'
                turnnumber +=1
                if turnnumber == 10:
                    return 'nobody'

        for i in range(len(gamefield)):
            for k in range(len(gamefield[i])):
                text = gamefield[i][k]
                if not text == None:
                    pes.pywrite(text, k * 167 + 100, i * 167 + 100, 167)

        pes.standardend()
        clock.tick(60)

def main():
    winner = ''
    while True:
        pes.standardstart()
        mousepress = pg.mouse.get_pressed()[0]
        if mousepress:
            winner = gameoftictactoe()
            pes.standardstart()
            pes.pywrite(winner + ' is the winner', size=50)
            pes.standardend()
            time.sleep(1)
        if not winner == '':
            pes.pywrite(winner + ' is the winner', size=50)
        pes.pywrite('press to play', y=100, size=75)
        pes.standardend()
    
if __name__ == '__main__':
    main()