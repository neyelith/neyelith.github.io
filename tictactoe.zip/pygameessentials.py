import pygame, pygame_widgets, sys, os

x = 300
y = 100
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)
screenwidth = 700
screenheight = 700
pygame.init()
screen = pygame.display.set_mode((screenwidth, screenheight))
clock = pygame.time.Clock()

def standardstart():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill("grey")

def standardend():
    pygame_widgets.update(pygame.event.get())
    pygame.display.update()
    pygame.display.flip()

def pywrite(text = '', x = 0, y = 0, size = 20, font = "monospace", color = (0, 0, 0)):
    screen.blit(pygame.font.SysFont(font, size).render(text, 1, color), (x, y))

def overmax(currentvalue = 0, maxvalue = 100):
    return abs(int(currentvalue/maxvalue) - 1)
